#!/bin/sh
set -eu
if [ -d /sys/module/uvcvideo ]; then rmmod uvcvideo; fi
modprobe uvcvideo
